# Proyecto Examen DRY7122 - Programación y Redes Virtualizadas

Este repositorio contiene scripts en Python para el examen transversal DRY7122.

## Scripts principales

- **integrantes.py**: imprime los nombres y apellidos del grupo.
- **vlan_check.py**: indica si una VLAN ingresada está en rango normal o extendido.
- **graphhopper_travel.py**: usa la API de Graphhopper para calcular distancia, duración y mostrar paso a paso el viaje entre dos ubicaciones con un perfil de vehículo.

## Cómo ejecutar

```bash
python3 integrantes.py
python3 vlan_check.py
python3 graphhopper_travel.py
```

> Reemplazar `api_key` en `graphhopper_travel.py` por tu API key personal.

## Autor

Gabriel Huenuman y grupo - DRY7122
