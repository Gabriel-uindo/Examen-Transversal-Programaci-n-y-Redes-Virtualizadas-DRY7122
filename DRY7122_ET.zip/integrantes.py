integrantes = ["Juan Pérez", "María Soto", "Pedro Díaz"]
print("Integrantes del grupo:")
for i in integrantes:
    print(i)
