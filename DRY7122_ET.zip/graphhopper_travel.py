import requests
import urllib.parse

api_key = "tu_api_key_aqui"  # Cambia por tu clave
route_url = "https://graphhopper.com/api/1/route?"

def geocoding(location, api_key):
    while location == "":
        location = input("Ingrese la ubicación nuevamente: ")
    geocode_url = "https://graphhopper.com/api/1/geocode?"
    url = geocode_url + urllib.parse.urlencode({"q": location, "limit": "1", "key": api_key})
    response = requests.get(url)
    json_data = response.json()
    status_code = response.status_code

    if status_code == 200 and len(json_data["hits"]) != 0:
        lat = json_data["hits"][0]["point"]["lat"]
        lon = json_data["hits"][0]["point"]["lng"]
        name = json_data["hits"][0]["name"]
        value = json_data["hits"][0]["osm_value"]
        country = json_data["hits"][0].get("country", "")
        state = json_data["hits"][0].get("state", "")
        if state and country:
            full_location_name = f"{name}, {state}, {country}"
        elif state:
            full_location_name = f"{name}, {state}"
        else:
            full_location_name = name
        print(f"Geocoding API URL para {full_location_name} (Tipo: {value})\n{url}")
    else:
        lat, lon, full_location_name = "null", "null", location
        if status_code != 200:
            print(f"Geocode API status: {status_code}\nMensaje: {json_data.get('message', '')}")
    return status_code, lat, lon, full_location_name

while True:
    print("\n+++++++++++++++++++++++++++++++++++++++++++++")
    print("Perfiles de vehículo disponibles en Graphhopper:")
    print("+++++++++++++++++++++++++++++++++++++++++++++")
    print("car, bike, foot")
    print("+++++++++++++++++++++++++++++++++++++++++++++")
    vehicle_options = ["car", "bike", "foot"]
    vehicle_type = input("Ingrese un perfil de vehículo: ")
    if vehicle_type in ["quit", "q"]:
        break
    elif vehicle_type not in vehicle_options:
        vehicle_type = "car"
        print("No se ingresó un perfil válido, usando 'car' por defecto.")

    start_location = input("Ubicación de origen: ")
    if start_location in ["quit", "q"]:
        break
    start_data = geocoding(start_location, api_key)

    end_location = input("Ubicación de destino: ")
    if end_location in ["quit", "q"]:
        break
    end_data = geocoding(end_location, api_key)

    print("=================================================")
    if start_data[0] == 200 and end_data[0] == 200:
        origin_point = "&point=" + str(start_data[1]) + "%2C" + str(start_data[2])
        destination_point = "&point=" + str(end_data[1]) + "%2C" + str(end_data[2])
        full_route_url = (
            route_url + urllib.parse.urlencode({"key": api_key, "vehicle": vehicle_type})
            + origin_point + destination_point
        )
        route_response = requests.get(full_route_url)
        route_status = route_response.status_code
        route_data = route_response.json()

        print(f"Routing API Status: {route_status}\nRouting API URL:\n{full_route_url}")
        print("=================================================")
        print(f"Dirección desde {start_data[3]} hasta {end_data[3]} usando {vehicle_type}")
        print("=================================================")

        if route_status == 200:
            miles = route_data["paths"][0]["distance"] / 1000 / 1.61
            km = route_data["paths"][0]["distance"] / 1000
            sec = int(route_data["paths"][0]["time"]/1000 % 60)
            min = int(route_data["paths"][0]["time"]/1000/60 % 60)
            hr = int(route_data["paths"][0]["time"]/1000/60/60)
            print(f"Distancia total: {miles:.1f} miles / {km:.1f} km")
            print(f"Duración estimada: {hr:02d}:{min:02d}:{sec:02d}")
            print("=================================================")
            for instruction in route_data["paths"][0]["instructions"]:
                step_text = instruction["text"]
                step_distance = instruction["distance"]
                print(f"{step_text} ( {step_distance/1000:.1f} km / {step_distance/1000/1.61:.1f} miles )")
            print("=================================================")
        else:
            print("Mensaje de error:", route_data.get("message", "No se pudo calcular la ruta."))
            print("*************************************************")
